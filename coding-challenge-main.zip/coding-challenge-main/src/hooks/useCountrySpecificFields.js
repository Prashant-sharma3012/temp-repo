import { useEffect, useState } from "react";


const DEFAULT_FIELDS = [
    { label: "First Name", type: "text", name: "firstName", validations: { required: true } },
    { label: "Last Name", type: "text", name: "lastName", validations: { required: true } },
    { label: "Date of Birth", type: "date", name: "dateOfBirth", validations: { required: true } },
    { label: "Holiday Allowance", type: "number", name: "holidayAllowance", validations: { required: true } },
];

const SPECIAL_FIELDS = {
    "brazil" : [
        { label: "Working Hours", type: "number", name: "workingHours", validations: { required: true, max: 50 } },
    ],
    "ghana": [
        { label: "Married", type: "checkbox", name: "married", validations: { required: true } },
        { label: "No of Children", type: "number", name: "noOfChildren", validations: { required: true } },
    ],
    "spain": [
        { label: "Married", type: "checkbox", name: "married", required: true },
        { label: "Social Security Number", type: "text", name: "socialSecurityNumber", validations: { required: true } },
    ]
};

const useCountrySpecificFields = (country) => {
    const [fields, setFields] = useState([]);
    useEffect(() => {
        switch (country) {
            case "brazil":
                setFields(DEFAULT_FIELDS.concat(SPECIAL_FIELDS.brazil));
                break;
            case "ghana":
                setFields(DEFAULT_FIELDS.concat(SPECIAL_FIELDS.ghana));
                break;
            case "spain":
                setFields(DEFAULT_FIELDS.concat(SPECIAL_FIELDS.spain));
                break;
            default:
                setFields([]);
        }


        return () => { };    // clean up
    }, [country]);


    return [fields];
};


export default useCountrySpecificFields;