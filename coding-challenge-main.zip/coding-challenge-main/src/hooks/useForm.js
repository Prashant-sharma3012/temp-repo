import { useReducer, useEffect } from 'react';

function formReducer(state = {}, action) {
    switch (action.type) {
        case "create":
            return { ...state, [action.name]: action.value || "" };
        case "update":
            return { ...state, [action.name]: action.value };
        case "reset":
            return {};
        default:
            return state;
    }
}


// helpers
function isReqired(v) { return v === "" }

function min(v, c) { return v <= c }

function max(v, c) { return v >= c }

// define what fields should look like for a better api and usage
export const useForm = (fields) => {
    const [state, dispatch] = useReducer(formReducer, {});
    const errors = []

    useEffect(() => {
        fields.forEach(({ name, value }) => {
            dispatch({ type: "create", name, value });
        });
    }, [fields]);

    const fieldWiseValidation = fields.reduce((acc, curr) => {
        acc = {
            ...acc,
            [curr.name]: curr.validations
        }

        return acc;
    }, {})


    const validate = () => {
        if(!fieldWiseValidation && Object.keys(fieldWiseValidation).length) {
            return;
        }

        Object.keys(state).forEach(k => {
            let validationRules = fieldWiseValidation[k]
            if (validationRules?.required && isReqired(state[k])) {
                return errors.push({
                    [k]: state[k]
                })
            }

            if (validationRules?.max && max(state[k], validationRules.max)) {
                return errors.push({
                    [k]: state[k]
                })
            }
        })
    }

    const reset = () => {
        dispatch({ type: 'reset' })
    }

    const update = (event) => {
        switch (event.target.type) {
            case "checkbox":
                dispatch({ type: 'update', name: event.target.name, value: event.target.checked });
                break;
            default:
                dispatch({ type: 'update', name: event.target.name, value: event.target.value });
        }
        if(validateOnChange){
            validate()
        }
    }

    return { formData: state, reset, errors, validate, update }
}