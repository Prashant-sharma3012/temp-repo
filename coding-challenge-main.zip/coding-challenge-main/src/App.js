import { useState, useEffect } from 'react';

import './App.css';
import Input from './components/Input';
import useCountrySpecificFields from './hooks/useCountrySpecificFields';
import { useForm } from './hooks/useForm'

const WORK_COUNTRIES = [
  { name: "Brazil", value: "brazil" },
  { name: "Ghana", value: "ghana" },
  { name: "Spain", value: "spain" }
];


function App() {
  // hooks
  const [workCountry, setWorkCountry] = useState("");
  const [fields] = useCountrySpecificFields(workCountry);
  const { formData, reset, update, errors, validate } = useForm(fields);

  // handlers
  const onCountryChangeHandler = (e) => {
    reset();
    setWorkCountry(e.currentTarget.value);
  };

  const onSubmitHandler = (event) => {
    event.preventDefault();
    validate()
    console.log(errors)
    console.log({
      workCountry,
      ...formData
    });
  };

  const onResetHandler = (event) => {
    event.preventDefault();
    reset();
  };

  useEffect(() => {
    if (!WORK_COUNTRIES.find(({ value }) => value === workCountry)) {
      setWorkCountry("");
    }
  }, [workCountry]);


  return (
    <div className="App">
      <form onSubmit={onSubmitHandler} onReset={onResetHandler} noValidate>
        <div className="form-group">
          <label>Country of Work</label>
          <select id="country" onChange={onCountryChangeHandler}>
            <option value="">Select a country</option>
            {WORK_COUNTRIES.map(({ name, value }) => (<option key={value} value={value}>{name}</option>))}
          </select>
        </div>

        {fields.map(({ label, name, type }) => (
          <Input key={name} type={type} name={name} value={formData[name] ?? ""} label={label} onChange={update} />)
        )}

        {fields.length > 0 && (<div className="form-group-inline mt-20">
          <Input type="submit" value="Submit" />
          <Input type="reset" value="Reset" onClick={onResetHandler} />
        </div>)}

      </form>
    </div>
  )
};

export default App;
