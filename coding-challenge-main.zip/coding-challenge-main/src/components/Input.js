import React from 'react';


const Input = (props) => {
    const { name, type, value, onChange, label, required } = props;
    return (
        <div className="form-group" key={name}>
            <label htmlFor={name}>{label}</label>
            <input id={name} data-testid={`app-${props.name}`} name={name} type={type} value={value} onChange={onChange} required={required}></input>
        </div>
    );
};

export default Input;