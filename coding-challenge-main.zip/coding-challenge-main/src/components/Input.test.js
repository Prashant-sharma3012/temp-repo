import { screen, fireEvent, render, prettyDOM } from "@testing-library/react";
import Input from "./Input";


describe("Input", () => {

    it("should render Input component", () => {
        const handler = jest.fn();
        render(<Input name="name" value="" onChange={handler} />);
    })

    it("should render Checkbox component", () => {
        const handler = jest.fn();
        render(<Input type="checkbox" name="correct" value="" onChange={handler} />);
        fireEvent.click(screen.getByTestId("app-correct"));
        expect(screen.getByTestId("app-correct")).toBeChecked();
    })

});